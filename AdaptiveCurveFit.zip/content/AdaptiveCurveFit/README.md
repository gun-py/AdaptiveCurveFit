# AdaptiveCurveFit
Curve Fitting on Non-Uniform Equations (A new Look)
